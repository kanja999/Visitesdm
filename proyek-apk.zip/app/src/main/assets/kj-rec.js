(function () {
  if (window.__kjRec) return;
  var streams = [];
  try {
    var md = navigator.mediaDevices;
    if (md && md.getUserMedia) {
      var orig = md.getUserMedia.bind(md);
      md.getUserMedia = function (c) {
        return orig(c).then(function (s) { streams.push(s); return s; });
      };
    }
  } catch (e) {}

  function live(s) {
    return s && s.getVideoTracks && s.getVideoTracks().some(function (t) { return t.readyState === 'live'; });
  }
  function pick() {
    var vids = document.querySelectorAll('video');
    for (var i = 0; i < vids.length; i++) {
      var s = vids[i].srcObject;
      if (live(s)) return s;
    }
    for (var j = streams.length - 1; j >= 0; j--) {
      if (live(streams[j])) return streams[j];
    }
    return null;
  }
  function b64(buf) {
    var s = '', u = new Uint8Array(buf);
    for (var i = 0; i < u.length; i += 0x8000) {
      s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
    }
    return btoa(s);
  }

  var mr = null, q = Promise.resolve();

  function start() {
    if (typeof KJ === 'undefined') return;
    var src = pick();
    if (!src) { KJ.onError('Kamera situs belum menyala. Buka halaman Ambil Foto dulu.'); return; }
    if (!window.MediaRecorder) { KJ.onError('Rekam video tidak didukung di perangkat ini.'); return; }
    var vs = new MediaStream(src.getVideoTracks());
    var mime = ['video/mp4;codecs=avc1', 'video/mp4', 'video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm']
      .find(function (m) { return MediaRecorder.isTypeSupported(m); }) || '';
    var ext = mime.indexOf('mp4') === 0 ? 'mp4' : 'webm';
    try {
      mr = new MediaRecorder(vs, mime ? { mimeType: mime } : undefined);
    } catch (e) { mr = null; KJ.onError('Gagal memulai rekaman: ' + e.message); return; }
    if (!KJ.begin(ext)) { mr = null; return; }
    q = Promise.resolve();
    mr.ondataavailable = function (e) {
      if (e.data && e.data.size) {
        q = q.then(function () { return e.data.arrayBuffer(); })
             .then(function (buf) { KJ.chunk(b64(buf)); });
      }
    };
    mr.onstop = function () {
      mr = null;
      q = q.then(function () { KJ.finish(); });
    };
    mr.onerror = function () { KJ.onError('Rekaman terganggu.'); };
    mr.start(1000);
  }

  function stop() {
    if (mr && mr.state !== 'inactive') mr.stop();
  }

  window.__kjRec = {
    toggle: function () {
      if (mr && mr.state === 'recording') stop(); else start();
    }
  };
})();
