package com.iswan.visitrec;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    static final String HOME = "https://login.suryadermatomedica.co.id/";
    static final String VISIT = "https://aplikasi5.suryadermatomedica.co.id/KJ/visit/";
    static final String HOST_SUFFIX = "suryadermatomedica.co.id";

    private WebView web;
    private Button rec;
    private final Handler h = new Handler(Looper.getMainLooper());
    private String injectJs = "";
    private volatile boolean hostOk = false;

    private PermissionRequest pendingReq;
    private String[] pendingRes;
    private GeolocationPermissions.Callback geoCb;
    private String geoOrigin;
    private ValueCallback<Uri[]> fileCb;

    private OutputStream out;
    private Uri outUri;
    private boolean recording = false;
    private long t0;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!recording) return;
            long s = (SystemClock.elapsedRealtime() - t0) / 1000;
            rec.setText(String.format(Locale.US, "%02d:%02d", s / 60, s % 60));
            h.postDelayed(this, 500);
        }
    };

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private boolean has(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private String readAsset(String n) {
        try (InputStream in = getAssets().open(n)) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int r;
            while ((r = in.read(buf)) > 0) b.write(buf, 0, r);
            return b.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private GradientDrawable circle(boolean on) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        if (on) {
            g.setColor(0xE5222222);
            g.setStroke(dp(3), 0xFFE5353B);
        } else {
            g.setColor(0xE5E5353B);
        }
        return g;
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        injectJs = readAsset("kj-rec.js");

        FrameLayout root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        rec = new Button(this);
        rec.setText("REC");
        rec.setTextColor(Color.WHITE);
        rec.setTextSize(12);
        rec.setTypeface(null, Typeface.BOLD);
        rec.setAllCaps(false);
        rec.setMinWidth(0);
        rec.setMinimumWidth(0);
        rec.setMinHeight(0);
        rec.setMinimumHeight(0);
        rec.setPadding(0, 0, 0, 0);
        rec.setBackground(circle(false));
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(dp(64), dp(64), Gravity.BOTTOM | Gravity.END);
        rp.setMargins(0, 0, dp(16), dp(110));
        root.addView(rec, rp);
        rec.setOnClickListener(v -> web.evaluateJavascript(
                "(window.__kjRec?window.__kjRec.toggle():KJ.onError('Halaman belum siap, coba lagi'))", null));

        Button kj = new Button(this);
        kj.setText("Kunjungan");
        kj.setTextColor(Color.WHITE);
        kj.setTextSize(11);
        kj.setAllCaps(false);
        kj.setMinWidth(0);
        kj.setMinimumWidth(0);
        kj.setMinHeight(0);
        kj.setMinimumHeight(0);
        kj.setPadding(dp(12), 0, dp(12), 0);
        GradientDrawable pill = new GradientDrawable();
        pill.setShape(GradientDrawable.RECTANGLE);
        pill.setCornerRadius(dp(18));
        pill.setColor(0xCC0F9D8A);
        kj.setBackground(pill);
        FrameLayout.LayoutParams kp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(36), Gravity.BOTTOM | Gravity.START);
        kp.setMargins(dp(12), 0, 0, dp(110));
        root.addView(kj, kp);
        kj.setOnClickListener(v -> web.loadUrl(VISIT));

        setContentView(root);
        setupWeb();
        web.loadUrl(HOME);
    }

    private void setupWeb() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new Bridge(), "KJ");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sc = u.getScheme();
                if ("http".equals(sc) || "https".equals(sc)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap icon) {
                String host = Uri.parse(url).getHost();
                hostOk = host != null && host.endsWith(HOST_SUFFIX);
                finishFile(false);
                if (hostOk) v.evaluateJavascript(injectJs, null);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (hostOk) v.evaluateJavascript(injectJs, null);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    if (pendingReq != null) { pendingReq.deny(); pendingReq = null; }
                    List<String> need = new ArrayList<>();
                    boolean any = false;
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) {
                            any = true;
                            if (!has(Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA);
                        } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) {
                            any = true;
                            if (!has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO);
                        }
                    }
                    if (!any) { request.deny(); return; }
                    if (need.isEmpty()) {
                        grantAllowed(request);
                    } else {
                        pendingReq = request;
                        requestPermissions(need.toArray(new String[0]), 1);
                    }
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (has(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    cb.invoke(origin, true, false);
                } else {
                    geoOrigin = origin;
                    geoCb = cb;
                    requestPermissions(new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION}, 2);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), 9);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });
    }

    private void grantAllowed(PermissionRequest request) {
        List<String> g = new ArrayList<>();
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && has(Manifest.permission.CAMERA)) g.add(r);
            else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && has(Manifest.permission.RECORD_AUDIO)) g.add(r);
        }
        if (g.isEmpty()) request.deny(); else request.grant(g.toArray(new String[0]));
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == 1 && pendingReq != null) {
            grantAllowed(pendingReq);
            pendingReq = null;
        }
        if (code == 2 && geoCb != null) {
            geoCb.invoke(geoOrigin, has(Manifest.permission.ACCESS_FINE_LOCATION)
                    || has(Manifest.permission.ACCESS_COARSE_LOCATION), false);
            geoCb = null;
        }
    }

    @Override
    protected void onActivityResult(int code, int res, Intent data) {
        super.onActivityResult(code, res, data);
        if (code == 9 && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        finishFile(false);
        web.destroy();
        super.onDestroy();
    }

    private void toast(final String m) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show());
    }

    private void setRecUi(boolean on) {
        recording = on;
        if (on) {
            t0 = SystemClock.elapsedRealtime();
            web.setKeepScreenOn(true);
            rec.setBackground(circle(true));
            h.post(ticker);
        } else {
            web.setKeepScreenOn(false);
            h.removeCallbacks(ticker);
            rec.setText("REC");
            rec.setBackground(circle(false));
        }
    }

    private synchronized void finishFile(boolean announce) {
        if (out == null) {
            if (recording) setRecUi(false);
            return;
        }
        try { out.flush(); out.close(); } catch (Exception e) { }
        out = null;
        if (outUri != null) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Video.Media.IS_PENDING, 0);
            try { getContentResolver().update(outUri, v, null, null); } catch (Exception e) { }
            outUri = null;
        }
        setRecUi(false);
        if (announce) toast("Done. Video kunjungan tersimpan (Movies/Kunjungan)");
    }

    class Bridge {
        @JavascriptInterface
        public synchronized boolean begin(String ext) {
            if (!hostOk) return false;
            try {
                if (out != null) { out.close(); out = null; }
                String name = "Kunjungan_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date())
                        + "." + ext;
                ContentValues v = new ContentValues();
                v.put(MediaStore.Video.Media.DISPLAY_NAME, name);
                v.put(MediaStore.Video.Media.MIME_TYPE, "mp4".equals(ext) ? "video/mp4" : "video/webm");
                v.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Kunjungan");
                v.put(MediaStore.Video.Media.IS_PENDING, 1);
                outUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
                if (outUri == null) throw new IOException("tidak bisa membuat file");
                out = getContentResolver().openOutputStream(outUri);
                runOnUiThread(() -> setRecUi(true));
                return true;
            } catch (Exception e) {
                toast("Gagal menyimpan video: " + e.getMessage());
                return false;
            }
        }

        @JavascriptInterface
        public synchronized void chunk(String b64) {
            try {
                if (out != null) out.write(Base64.decode(b64, Base64.DEFAULT));
            } catch (Exception e) {
                toast("Gagal menulis video: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public void finish() {
            runOnUiThread(() -> finishFile(true));
        }

        @JavascriptInterface
        public void onError(String m) {
            toast(m);
        }
    }
}
